
//to communicate between content.js and popup.js
try {
    const runtime = (typeof browser !== "undefined" ? browser : chrome)?.runtime;
    runtime?.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "hoverDetails") {
            runtime?.sendMessage(message);
        }
    });
}
catch (error) {
}