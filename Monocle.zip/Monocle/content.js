
$(document).ready(function() {
    $(document).on("mouseover", function (event) {
        try {
            const hoveredElement = event.target;

            //hovered element
            const details = {
                innerText: hoveredElement.innerText
            };

            //send the details for hovered element to extension from any site
            const runtime = (typeof browser !== "undefined" ? browser : chrome)?.runtime;
            runtime?.sendMessage({ action: "hoverDetails", details: details });
        }
        catch (error) {
        }
    });
});