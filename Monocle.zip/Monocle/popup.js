
//bind the hovered text and display magnified text  
function handleMessage(message, sender, sendResponse) {
    try {
        if (message.action === "hoverDetails") {
            var emptyData = "N/A";
            document.getElementById("displayHoveredText").textContent =
                `${(message.details.innerText == null ? emptyData : message.details.innerText) || emptyData}`;
        }
    }
    catch (error) {
    }
}

try {
    //listen to the hovered element details
    const runtime = (typeof browser !== "undefined" ? browser : chrome)?.runtime;
    runtime?.onMessage.addListener(handleMessage);
} catch (error) { }

